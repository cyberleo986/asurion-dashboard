# Gemini Gem Dashboard - Project TODO

## Database & Schema
- [x] Design and implement devices table schema
- [x] Design and implement claims table schema
- [x] Design and implement system_log table schema
- [x] Design and implement policies and policy_rules tables
- [x] Generate and apply database migrations
- [x] Add `manualReviewReason` column on devices (migration `0002_*`)

## Backend Procedures
- [x] Create device query helpers (list, filter, search, update price, mark resolved)
- [x] Create claims query helpers (list, filter by device, claims-for-device)
- [x] Create system_log query helpers (list, search, filter by actor/action)
- [x] Implement tRPC procedures for devices (list, update, resolve, setManualReviewReason)
- [x] Implement tRPC procedures for claims (list, get by device, submit)
- [x] Implement tRPC procedures for system_log (list, search)
- [x] Implement tRPC procedures for dashboard stats (counts by status, incl. CLAIM_READY)
- [x] Implement `claims.generate` mutation — picks best policy, computes payout, writes audit log
- [x] Implement policy-selection helpers (`getPolicyRulesForCategory`, `selectBestPolicyForCategory`, `calculatePayout`)
- [x] Create demo data seeding procedure

## Frontend Components & Pages
- [x] Configure dark theme with navy/cyan/amber color scheme
- [x] Implement DashboardLayout with sidebar navigation
- [x] Create Overview page with KPI cards and pipeline chart (now includes CLAIM_READY)
- [x] Create Devices table page with filtering, inline editing, and **Generate Claim** button
- [x] Create Claims table page with claim details, status badges, KPI cards, Submit action
- [x] Create Manual Review queue page with inline price entry, reason editing, Resolve/Dismiss
- [x] Create Audit Log page with actor/action search and richer details rendering
- [x] Implement responsive design and mobile considerations

## Testing & Validation
- [x] Write vitest tests for backend procedures (now covers claims.generate + claims.submit)
- [x] Write vitest tests for db helpers (now covers payout calc + policy selection)
- [x] Test demo data seeding on first load
- [x] Verify all CRUD operations work correctly
- [x] Test filtering and search functionality
- [x] Validate dark theme consistency across all pages

## Notifications & Eligibility Features
- [x] Implement owner push notifications for key events (toast notifications)
- [x] Add claims eligibility checker procedure (backend) — returns list of eligible policies
- [x] Display claims eligibility badge on Devices table
- [x] Show eligible policies for each device
- [x] Add notification toast for claim-ready devices
- [x] **Create "Generate Claim" button for eligible devices** — wired to `claims.generate` mutation

## Deployment & Delivery
- [x] Create initial checkpoint
- [x] Verify all features work end-to-end
- [x] Document any manual setup steps
- [x] Deliver dashboard to user
- [x] Bring dashboard guide, deployment runbook, and master blueprint in sync with current code