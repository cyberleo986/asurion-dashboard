import { trpc } from "@/lib/trpc";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, RefreshCcw, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";

export default function ManualReview() {
  const utils = trpc.useUtils();
  const { data: devices, isLoading, refetch } = trpc.devices.list.useQuery({
    status: "MANUAL_REVIEW",
  });

  const updatePriceMutation = trpc.devices.updatePrice.useMutation({
    onSuccess: () => {
      toast.success("Device price updated and re-queued for valuation.");
      refetch();
      utils.devices.list.invalidate();
    },
    onError: (error) => {
      toast.error("Failed to update device price.", { description: error.message });
    },
  });

  const updateStatusMutation = trpc.devices.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Device marked as VALUATED.");
      refetch();
      utils.devices.list.invalidate();
      utils.dashboard.stats.invalidate();
    },
    onError: (error) => {
      toast.error("Failed to update device status.", { description: error.message });
    },
  });

  const setReasonMutation = trpc.devices.setManualReviewReason.useMutation({
    onSuccess: () => {
      toast.success("Manual-review reason updated.");
      refetch();
    },
    onError: (error) => {
      toast.error("Failed to update reason.", { description: error.message });
    },
  });

  const handlePriceUpdate = (id: number, price: string) => {
    const parsedPrice = parseInt(price, 10);
    if (!isNaN(parsedPrice) && parsedPrice > 0) {
      // Setting a price auto-resolves the manual review → push device back to VALUATED.
      updatePriceMutation.mutate({ id, price: parsedPrice });
      updateStatusMutation.mutate({ id, status: "VALUATED" });
    } else {
      toast.error("Invalid price", { description: "Please enter a valid positive number." });
    }
  };

  const handleResolve = (id: number) => {
    updateStatusMutation.mutate({ id, status: "VALUATED" });
  };

  const handleDismiss = (id: number) => {
    setReasonMutation.mutate({ id, reason: null });
    updateStatusMutation.mutate({ id, status: "INGESTED" });
  };

  const handleReasonUpdate = (id: number, reason: string) => {
    setReasonMutation.mutate({ id, reason: reason || null });
  };

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Manual Review Queue</h2>
        <Button onClick={() => refetch()} variant="outline">
          <RefreshCcw className="mr-2 h-4 w-4" /> Refresh
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Devices Needing Review</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Brand</TableHead>
                  <TableHead>Model</TableHead>
                  <TableHead>Serial Number</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      <Loader2 className="h-6 w-6 animate-spin inline-block mr-2" /> Loading devices...
                    </TableCell>
                  </TableRow>
                ) : devices?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      No devices require manual review.
                    </TableCell>
                  </TableRow>
                ) : (
                  devices?.map((device: {
                    id: number;
                    brand: string;
                    model: string;
                    serialNumber: string;
                    category: string;
                    manualReviewReason: string | null;
                    status: string;
                  }) => (
                    <TableRow key={device.id}>
                      <TableCell>{device.id}</TableCell>
                      <TableCell>{device.brand}</TableCell>
                      <TableCell>{device.model}</TableCell>
                      <TableCell>{device.serialNumber}</TableCell>
                      <TableCell>{device.category}</TableCell>
                      <TableCell>
                        <Input
                          type="text"
                          defaultValue={device.manualReviewReason ?? ""}
                          placeholder="e.g. price_not_found"
                          onBlur={(e) => handleReasonUpdate(device.id, e.target.value)}
                          className="w-56"
                        />
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Input
                            type="number"
                            placeholder="Enter Price ($)"
                            onBlur={(e) => handlePriceUpdate(device.id, e.target.value)}
                            className="w-36"
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleResolve(device.id)}
                          >
                            <CheckCircle className="mr-2 h-4 w-4" /> Resolve
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDismiss(device.id)}
                          >
                            <XCircle className="mr-2 h-4 w-4" /> Dismiss
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}