import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Policies (Master list of insurance types)
export const policies = mysqlTable("policies", {
  id: int("id").autoincrement().primaryKey(),
  policyName: text("policyName").notNull(),
  policyShortName: varchar("policyShortName", { length: 32 }).notNull().unique(),
  isGloballyActive: int("isGloballyActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Policy = typeof policies.$inferSelect;
export type InsertPolicy = typeof policies.$inferInsert;

// Policy Rules (Deductibles and prioritization per category)
export const policyRules = mysqlTable("policyRules", {
  id: int("id").autoincrement().primaryKey(),
  policyId: int("policyId").references(() => policies.id),
  deviceCategory: text("deviceCategory").notNull(),
  deductibleAmount: int("deductibleAmount").notNull(),
  isAdhCovered: int("isAdhCovered").default(0).notNull(),
  priorityForTieBreak: int("priorityForTieBreak").notNull(),
});

export type PolicyRule = typeof policyRules.$inferSelect;
export type InsertPolicyRule = typeof policyRules.$inferInsert;

// Devices (Inventory ledger)
export const devices = mysqlTable("devices", {
  id: int("id").autoincrement().primaryKey(),
  brand: varchar("brand", { length: 255 }),
  model: varchar("model", { length: 255 }),
  serialNumber: varchar("serialNumber", { length: 255 }).unique(),
  category: varchar("category", { length: 255 }),
  scanilyUrl: text("scanilyUrl"),
  retailPriceEstimate: int("retailPriceEstimate"), // in cents
  status: mysqlEnum("status", ["INGESTED", "VALUATED", "MANUAL_REVIEW", "CLAIM_READY", "CLAIMED"]).default("INGESTED").notNull(),
  manualReviewReason: text("manualReviewReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Device = typeof devices.$inferSelect;
export type InsertDevice = typeof devices.$inferInsert;

// Claims (Execution ledger)
export const claims = mysqlTable("claims", {
  id: int("id").autoincrement().primaryKey(),
  deviceId: int("deviceId").references(() => devices.id),
  targetPolicyId: int("targetPolicyId").references(() => policies.id),
  status: mysqlEnum("status", ["PROCESSING", "PDF_GENERATED", "FAILED", "SUBMITTED", "DRY_RUN_COMPLETE"]).notNull(),
  failureDate: timestamp("failureDate"),
  failureDescription: text("failureDescription"),
  payoutEstimate: int("payoutEstimate"), // in cents
  generatedPdfFilename: varchar("generatedPdfFilename", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Claim = typeof claims.$inferSelect;
export type InsertClaim = typeof claims.$inferInsert;

// System Log (Forensic audit trail)
export const systemLogs = mysqlTable("systemLogs", {
  id: int("id").autoincrement().primaryKey(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  actor: varchar("actor", { length: 255 }).notNull(),
  action: varchar("action", { length: 255 }).notNull(),
  details: text("details"), // JSON stringified
});

export type SystemLog = typeof systemLogs.$inferSelect;
export type InsertSystemLog = typeof systemLogs.$inferInsert;