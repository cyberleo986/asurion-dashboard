import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";
import type { User } from "../drizzle/schema";

/**
 * tRPC Procedure tests
 * --------------------
 * These tests assume the test DB has already been seeded by `seedDemoData()`.
 * They exercise the protected mutations (updatePrice / updateStatus /
 * claims.generate / claims.submit) and the public queries (stats / list /
 * getById / checkEligibility).
 *
 * Run with: pnpm test
 */
describe("tRPC Procedures", () => {
  const mockUser: User = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "test",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const caller = appRouter.createCaller({
    user: mockUser,
    req: { headers: {}, protocol: "https" } as any,
    res: {} as any,
  });

  describe("dashboard.stats", () => {
    it("should return device counts by status", async () => {
      const stats = await caller.dashboard.stats();
      expect(stats).toBeDefined();
      expect(stats.INGESTED).toBeGreaterThanOrEqual(0);
      expect(stats.VALUATED).toBeGreaterThanOrEqual(0);
      expect(stats.MANUAL_REVIEW).toBeGreaterThanOrEqual(0);
      expect(stats.CLAIM_READY).toBeGreaterThanOrEqual(0);
      expect(stats.CLAIMED).toBeGreaterThanOrEqual(0);
    });
  });

  describe("devices.list", () => {
    it("should return list of devices", async () => {
      const result = await caller.devices.list({});
      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThanOrEqual(0);
    });

    it("should filter devices by status", async () => {
      const result = await caller.devices.list({ status: "VALUATED" });
      expect(result).toBeDefined();
      result.forEach((device) => {
        expect(device.status).toBe("VALUATED");
      });
    });

    it("should filter devices by brand", async () => {
      const result = await caller.devices.list({ brand: "Sony" });
      expect(result).toBeDefined();
      result.forEach((device) => {
        expect(device.brand).toBe("Sony");
      });
    });

    it("should search devices by query", async () => {
      const result = await caller.devices.list({ search: "iPad" });
      expect(result).toBeDefined();
      if (result.length > 0) {
        const hasMatch = result.some((d) =>
          d.model.toLowerCase().includes("ipad")
        );
        expect(hasMatch).toBe(true);
      }
    });
  });

  describe("devices.getById", () => {
    it("should get device by ID", async () => {
      const devices = await caller.devices.list({});
      if (devices.length > 0) {
        const deviceId = devices[0].id;
        const device = await caller.devices.getById({ id: deviceId });
        expect(device).toBeDefined();
        expect(device?.id).toBe(deviceId);
      }
    });
  });

  describe("claims.list", () => {
    it("should return list of claims", async () => {
      const result = await caller.claims.list({});
      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThanOrEqual(0);
    });

    it("should filter claims by status", async () => {
      const result = await caller.claims.list({ status: "PDF_GENERATED" });
      expect(result).toBeDefined();
      result.forEach((claim) => {
        expect(claim.status).toBe("PDF_GENERATED");
      });
    });
  });

  describe("claims.checkEligibility", () => {
    it("should check device eligibility for claims", async () => {
      const devices = await caller.devices.list({});
      if (devices.length > 0) {
        const deviceId = devices[0].id;
        const eligibility = await caller.claims.checkEligibility({ deviceId });
        expect(eligibility).toBeDefined();
        expect(eligibility.eligible).toBeDefined();
        expect(Array.isArray(eligibility.eligiblePolicies)).toBe(true);
      }
    });

    it("should return ineligible with reason for MANUAL_REVIEW devices", async () => {
      const devices = await caller.devices.list({ status: "MANUAL_REVIEW" });
      if (devices.length > 0) {
        const eligibility = await caller.claims.checkEligibility({ deviceId: devices[0].id });
        expect(eligibility.eligible).toBe(false);
        expect(eligibility.reason).toBeTruthy();
      }
    });
  });

  describe("claims.generate", () => {
    it("should reject generation for non-existent device", async () => {
      await expect(caller.claims.generate({ deviceId: 999999 })).rejects.toThrow();
    });

    it("should reject generation for INGESTED devices without price", async () => {
      const devices = await caller.devices.list({ status: "INGESTED" });
      const withPrice = devices.find((d) => !d.retailPriceEstimate);
      if (withPrice) {
        await expect(caller.claims.generate({ deviceId: withPrice.id })).rejects.toThrow();
      }
    });

    it("should generate a claim for an eligible VALUATED device", async () => {
      const devices = await caller.devices.list({ status: "VALUATED" });
      const eligible = devices.find((d) => Boolean(d.retailPriceEstimate));
      if (!eligible) return; // Skip if no eligible devices (already filed)

      const result = await caller.claims.generate({ deviceId: eligible.id });
      expect(result).toBeDefined();
      expect(result.claim).toBeDefined();
      expect(result.claim.deviceId).toBe(eligible.id);
      expect(result.claim.status).toBe("PDF_GENERATED");
      expect(result.claim.payoutEstimate).toBeGreaterThanOrEqual(0);
      expect(result.pdfFilename).toMatch(/^claim_.*\.pdf$/);

      // Device should now be CLAIMED
      const refreshed = await caller.devices.getById({ id: eligible.id });
      expect(refreshed?.status).toBe("CLAIMED");
    });

    it("should reject generating a second claim for the same device", async () => {
      const claims = await caller.claims.list({});
      const deviceId = claims[0]?.deviceId;
      if (deviceId && claims[0].status === "PDF_GENERATED") {
        await expect(caller.claims.generate({ deviceId })).rejects.toThrow();
      }
    });
  });

  describe("claims.submit", () => {
    it("should reject submission for SUBMITTED claims", async () => {
      const claims = await caller.claims.list({ status: "SUBMITTED" });
      if (claims.length > 0) {
        await expect(caller.claims.submit({ claimId: claims[0].id })).rejects.toThrow();
      }
    });
  });

  describe("logs.list", () => {
    it("should return list of system logs", async () => {
      const result = await caller.logs.list({});
      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThanOrEqual(0);
    });

    it("should search system logs", async () => {
      const result = await caller.logs.list({ search: "PRICE" });
      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
    });

    it("should filter logs by actor", async () => {
      const result = await caller.logs.list({ actor: "CLAIM_BOT" });
      expect(result).toBeDefined();
      result.forEach((log) => {
        expect(log.actor).toBe("CLAIM_BOT");
      });
    });

    it("should filter logs by action", async () => {
      const result = await caller.logs.list({ action: "PDF_GENERATED" });
      expect(result).toBeDefined();
      result.forEach((log) => {
        expect(log.action).toBe("PDF_GENERATED");
      });
    });
  });

  describe("devices.setManualReviewReason", () => {
    it("should set manual-review reason on a device", async () => {
      const devices = await caller.devices.list({ status: "MANUAL_REVIEW" });
      if (devices.length > 0) {
        const updated = await caller.devices.setManualReviewReason({
          id: devices[0].id,
          reason: "Updated reason for testing",
        });
        expect(updated).toBeDefined();
        expect(updated?.manualReviewReason).toBe("Updated reason for testing");
      }
    });
  });
});