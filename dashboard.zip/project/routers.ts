import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import {
  getDevices,
  getDeviceById,
  updateDevicePrice,
  updateDeviceStatus,
  updateDeviceManualReviewReason,
  getDeviceCountsByStatus,
  getClaims,
  getClaimById,
  getClaimsForDevice,
  createClaim,
  updateClaimStatus,
  getSystemLogs,
  createSystemLog,
  selectBestPolicyForCategory,
  getPolicyRulesForCategory,
  calculatePayout,
  seedDemoData,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Dashboard & Device Management
  dashboard: router({
    stats: publicProcedure.query(async () => {
      const counts = await getDeviceCountsByStatus();
      return {
        INGESTED: counts.INGESTED,
        VALUATED: counts.VALUATED,
        MANUAL_REVIEW: counts.MANUAL_REVIEW,
        CLAIM_READY: counts.CLAIM_READY,
        CLAIMED: counts.CLAIMED,
      };
    }),
  }),

  devices: router({
    list: publicProcedure
      .input(
        z.object({
          status: z.string().optional(),
          brand: z.string().optional(),
          category: z.string().optional(),
          search: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        return getDevices(input);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getDeviceById(input.id);
      }),

    updatePrice: protectedProcedure
      .input(z.object({ id: z.number(), price: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const before = await getDeviceById(input.id);
        if (!before) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Device not found" });
        }
        const device = await updateDevicePrice(input.id, input.price);
        await createSystemLog("DASHBOARD_USER", "DEVICE_PRICE_UPDATED", {
          device_id: input.id,
          old_price: before.retailPriceEstimate,
          new_price: input.price,
          user: ctx.user?.email,
        });
        return device;
      }),

    updateStatus: protectedProcedure
      .input(z.object({ id: z.number(), status: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const allowedStatuses = ["INGESTED", "VALUATED", "MANUAL_REVIEW", "CLAIM_READY", "CLAIMED"];
        if (!allowedStatuses.includes(input.status)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: `Invalid status: ${input.status}` });
        }
        const before = await getDeviceById(input.id);
        if (!before) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Device not found" });
        }
        const device = await updateDeviceStatus(input.id, input.status);
        await createSystemLog("DASHBOARD_USER", "DEVICE_STATUS_UPDATED", {
          device_id: input.id,
          old_status: before.status,
          new_status: input.status,
          user: ctx.user?.email,
        });
        return device;
      }),

    setManualReviewReason: protectedProcedure
      .input(z.object({ id: z.number(), reason: z.string().nullable() }))
      .mutation(async ({ input, ctx }) => {
        const device = await updateDeviceManualReviewReason(input.id, input.reason);
        await createSystemLog("DASHBOARD_USER", "DEVICE_REVIEW_REASON_SET", {
          device_id: input.id,
          reason: input.reason,
          user: ctx.user?.email,
        });
        return device;
      }),
  }),

  claims: router({
    list: publicProcedure
      .input(
        z.object({
          status: z.string().optional(),
          deviceId: z.number().optional(),
        })
      )
      .query(async ({ input }) => {
        return getClaims(input);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getClaimById(input.id);
      }),

    getForDevice: publicProcedure
      .input(z.object({ deviceId: z.number() }))
      .query(async ({ input }) => {
        return getClaimsForDevice(input.deviceId);
      }),

    checkEligibility: publicProcedure
      .input(z.object({ deviceId: z.number() }))
      .query(async ({ input }) => {
        type PolicySummary = {
          policyId: number;
          policyName: string;
          policyShortName: string;
          deductibleAmount: number;
          isAdhCovered: number;
          priorityForTieBreak: number;
        };
        const emptyPolicies: PolicySummary[] = [];
        const device = await getDeviceById(input.deviceId);
        if (!device) {
          return { eligible: false as const, reason: "Device not found", eligiblePolicies: emptyPolicies };
        }
        if (device.status !== "VALUATED" && device.status !== "CLAIM_READY") {
          return {
            eligible: false,
            reason: `Device status is ${device.status}, must be VALUATED or CLAIM_READY`,
            eligiblePolicies: [],
          };
        }
        if (!device.retailPriceEstimate) {
          return {
            eligible: false,
            reason: "Device has no retail price estimate",
            eligiblePolicies: [],
          };
        }
        // Determine which policies cover this category.
        let eligiblePolicies: Array<{
          policyId: number;
          policyName: string;
          policyShortName: string;
          deductibleAmount: number;
          isAdhCovered: number;
          priorityForTieBreak: number;
        }> = [];
        try {
          const matches = await getPolicyRulesForCategory(device.category ?? "");
          eligiblePolicies = matches.map((m: any) => ({
            policyId: m.policy.id,
            policyName: m.policy.policyName,
            policyShortName: m.policy.policyShortName,
            deductibleAmount: m.rule.deductibleAmount,
            isAdhCovered: m.rule.isAdhCovered,
            priorityForTieBreak: m.rule.priorityForTieBreak,
          }));
        } catch {
          eligiblePolicies = [];
        }
        const estimatedCoverage = device.retailPriceEstimate;
        return {
          eligible: true,
          device,
          estimatedCoverage,
          eligiblePolicies,
        };
      }),

    /**
     * Generates a claim for a single eligible device.
     *
     * Flow:
     *  1. Validate device exists + status is VALUATED / CLAIM_READY + has price.
     *  2. Refuse if device already has an open claim (PDF_GENERATED or SUBMITTED).
     *  3. Pick the highest-priority globally-active policy rule matching device category.
     *  4. Compute payout = max(retail_price - deductible, 0).
     *  5. Insert claim row with status PDF_GENERATED (PDF generation stubbed for dashboard;
     *     the Python gem_brain microservice owns real PDFOtter integration).
     *  6. Move device to CLAIMED.
     *  7. Write audit log.
     */
    generate: protectedProcedure
      .input(z.object({ deviceId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const device = await getDeviceById(input.deviceId);
        if (!device) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Device not found" });
        }
        if (device.status !== "VALUATED" && device.status !== "CLAIM_READY") {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: `Device status is ${device.status}, must be VALUATED or CLAIM_READY`,
          });
        }
        if (!device.retailPriceEstimate) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Device has no retail price estimate",
          });
        }
        // Refuse if an open claim already exists.
        const existing = await getClaimsForDevice(input.deviceId);
        const openClaim = existing.find((c) => c.status === "PDF_GENERATED" || c.status === "PROCESSING" || c.status === "SUBMITTED");
        if (openClaim) {
          throw new TRPCError({
            code: "CONFLICT",
            message: `Device already has an open claim (#${openClaim.id}, status ${openClaim.status})`,
          });
        }

        const policyMatch = await selectBestPolicyForCategory(device.category);
        if (!policyMatch) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: `No active policy rule covers category "${device.category ?? "unknown"}"`,
          });
        }
        const payout = calculatePayout(device.retailPriceEstimate, policyMatch.rule.deductibleAmount);
        const filename = `claim_${device.serialNumber}_${Date.now()}.pdf`;

        const claim = await createClaim({
          deviceId: device.id,
          targetPolicyId: policyMatch.policy.id,
          status: "PDF_GENERATED",
          payoutEstimate: payout,
          generatedPdfFilename: filename,
        });
        if (!claim) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to persist claim" });
        }

        await updateDeviceStatus(device.id, "CLAIMED");

        await createSystemLog("DASHBOARD_USER", "CLAIM_GENERATED", {
          device_id: device.id,
          claim_id: claim.id,
          policy_id: policyMatch.policy.id,
          policy_name: policyMatch.policy.policyName,
          payout_estimate: payout,
          pdf_filename: filename,
          user: ctx.user?.email,
        });

        return {
          claim,
          policy: {
            id: policyMatch.policy.id,
            name: policyMatch.policy.policyName,
            shortName: policyMatch.policy.policyShortName,
          },
          payout,
          pdfFilename: filename,
        };
      }),

    submit: protectedProcedure
      .input(z.object({ claimId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const claim = await getClaimById(input.claimId);
        if (!claim) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Claim not found" });
        }
        if (claim.status !== "PDF_GENERATED") {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: `Claim status is ${claim.status}, must be PDF_GENERATED to submit`,
          });
        }
        const updated = await updateClaimStatus(input.claimId, "SUBMITTED");
        await createSystemLog("DASHBOARD_USER", "CLAIM_SUBMITTED", {
          claim_id: input.claimId,
          device_id: claim.deviceId,
          user: ctx.user?.email,
        });
        return updated;
      }),
  }),

  logs: router({
    list: publicProcedure
      .input(
        z.object({
          actor: z.string().optional(),
          action: z.string().optional(),
          search: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        return getSystemLogs(input);
      }),
  }),

  // Demo data seeding
  demo: router({
    seed: publicProcedure.mutation(async () => {
      await seedDemoData();
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;