import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Search, RefreshCcw, Filter } from "lucide-react";
import { useDebounce } from "@/hooks/useDebounce";

function formatDetails(details: string | null): { primary: string; extra: string } {
  if (!details) return { primary: "—", extra: "" };
  try {
    const parsed = JSON.parse(details);
    if (parsed && typeof parsed === "object") {
      const entries = Object.entries(parsed);
      if (entries.length === 0) return { primary: "{}", extra: "" };
      const [k, v] = entries[0];
      const primary = `${k}: ${typeof v === "object" ? JSON.stringify(v) : String(v)}`;
      const extra =
        entries.length > 1
          ? entries
              .slice(1)
              .map(([ek, ev]) => `${ek}: ${typeof ev === "object" ? JSON.stringify(ev) : String(ev)}`)
              .join(" · ")
          : "";
      return { primary, extra };
    }
    return { primary: String(parsed), extra: "" };
  } catch {
    return { primary: details, extra: "" };
  }
}

const ACTOR_OPTIONS = ["", "INGEST_BOT", "VALUATION_BOT", "CLAIM_BOT", "ADMIN_USER", "DASHBOARD_USER", "system"];
const ACTION_OPTIONS = [
  "",
  "FILE_PROCESSED",
  "PRICE_FOUND",
  "MANUAL_REVIEW_FLAGGED",
  "PDF_GENERATED",
  "CLAIM_GENERATED",
  "CLAIM_SUBMITTED",
  "DEVICE_PRICE_UPDATED",
  "DEVICE_STATUS_UPDATED",
  "DEVICE_REVIEW_REASON_SET",
];

export default function AuditLog() {
  const [search, setSearch] = useState("");
  const [actorFilter, setActorFilter] = useState("");
  const [actionFilter, setActionFilter] = useState("");
  const debouncedSearch = useDebounce(search, 500);

  const { data: logs, isLoading, refetch } = trpc.logs.list.useQuery({
    search: debouncedSearch || undefined,
    actor: actorFilter || undefined,
    action: actionFilter || undefined,
  });

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Audit Log</h2>
        <Button onClick={() => refetch()} variant="outline">
          <RefreshCcw className="mr-2 h-4 w-4" /> Refresh
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>System Activity Log</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-4 flex-wrap">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by actor, action, or details..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8"
              />
            </div>
            <Select value={actorFilter} onValueChange={setActorFilter}>
              <SelectTrigger className="w-[200px]">
                <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="Filter by Actor" />
              </SelectTrigger>
              <SelectContent>
                {ACTOR_OPTIONS.map((opt) => (
                  <SelectItem key={opt || "all"} value={opt}>
                    {opt === "" ? "All Actors" : opt}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={actionFilter} onValueChange={setActionFilter}>
              <SelectTrigger className="w-[240px]">
                <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="Filter by Action" />
              </SelectTrigger>
              <SelectContent>
                {ACTION_OPTIONS.map((opt) => (
                  <SelectItem key={opt || "all"} value={opt}>
                    {opt === "" ? "All Actions" : opt.replace(/_/g, " ")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {(search || actorFilter || actionFilter) && (
              <Button
                variant="ghost"
                onClick={() => {
                  setSearch("");
                  setActorFilter("");
                  setActionFilter("");
                }}
              >
                Reset Filters
              </Button>
            )}
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[180px]">Timestamp</TableHead>
                  <TableHead className="w-[160px]">Actor</TableHead>
                  <TableHead className="w-[200px]">Action</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center">
                      <Loader2 className="h-6 w-6 animate-spin inline-block mr-2" /> Loading logs...
                    </TableCell>
                  </TableRow>
                ) : logs?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center">
                      No log entries found.
                    </TableCell>
                  </TableRow>
                ) : (
                  logs?.map((log: { id: number; timestamp: number; actor: string; action: string; details: string | null; }) => {
                    const { primary, extra } = formatDetails(log.details);
                    return (
                      <TableRow key={log.id}>
                        <TableCell className="font-mono text-xs">
                          {new Date(log.timestamp).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          <span className="inline-flex items-center rounded-full bg-muted px-2 py-0.5 text-xs font-medium">
                            {log.actor}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="inline-flex items-center rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                            {log.action.replace(/_/g, " ")}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">{primary}</div>
                          {extra && <div className="text-xs text-muted-foreground mt-0.5">{extra}</div>}
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}