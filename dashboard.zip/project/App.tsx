import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import DashboardLayout from "@/components/DashboardLayout";
import Overview from "./pages/Overview";
import Devices from "./pages/Devices";
import Claims from "./pages/Claims";
import ManualReview from "./pages/ManualReview";
import AuditLog from "./pages/AuditLog";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard/:rest*"} nest>
        {(params) => (
          <DashboardLayout>
            <Switch>
              <Route path={"/"} component={Overview} />
              <Route path={"/devices"} component={Devices} />
              <Route path={"/claims"} component={Claims} />
              <Route path={"/manual-review"} component={ManualReview} />
              <Route path={"/audit-log"} component={AuditLog} />
              <Route component={NotFound} />
            </Switch>
          </DashboardLayout>
        )}
      </Route>
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
