import { eq, desc, or, like, sql, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, devices, claims, policies, policyRules, systemLogs, InsertDevice, InsertClaim, InsertPolicy, InsertSystemLog } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ===== DEVICE QUERIES =====
export async function getDevices(filters?: {
  status?: string;
  brand?: string;
  category?: string;
  search?: string;
}) {
  const db = await getDb();
  if (!db) return [];

  let query: any = db.select().from(devices);

  if (filters?.status) {
    query = query.where(eq(devices.status, filters.status as any));
  }
  if (filters?.brand) {
    query = query.where(eq(devices.brand, filters.brand));
  }
  if (filters?.category) {
    query = query.where(eq(devices.category, filters.category));
  }
  if (filters?.search) {
    const searchLike = `%${filters.search}%`;
    query = query.where(
      or(
        like(devices.brand, searchLike),
        like(devices.model, searchLike),
        like(devices.serialNumber, searchLike)
      )
    );
  }

  return await query.orderBy(desc(devices.createdAt));
}

export async function getDeviceById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(devices).where(eq(devices.id, id)).limit(1);
  return result[0] || null;
}

export async function updateDevicePrice(id: number, price: number) {
  const db = await getDb();
  if (!db) return null;
  await db.update(devices).set({ retailPriceEstimate: price }).where(eq(devices.id, id));
  return getDeviceById(id);
}

export async function updateDeviceStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) return null;
  await db.update(devices).set({ status: status as any }).where(eq(devices.id, id));
  return getDeviceById(id);
}

export async function updateDeviceManualReviewReason(id: number, reason: string | null) {
  const db = await getDb();
  if (!db) return null;
  await db.update(devices).set({ manualReviewReason: reason }).where(eq(devices.id, id));
  return getDeviceById(id);
}

export async function getDeviceCountsByStatus() {
  const db = await getDb();
  if (!db) return { INGESTED: 0, VALUATED: 0, MANUAL_REVIEW: 0, CLAIM_READY: 0, CLAIMED: 0 };

  const result = await db.select({
    status: devices.status,
    count: sql<number>`COUNT(*)`
  }).from(devices).groupBy(devices.status);

  const counts = { INGESTED: 0, VALUATED: 0, MANUAL_REVIEW: 0, CLAIM_READY: 0, CLAIMED: 0 };
  result.forEach((row: any) => {
    if (row.status in counts) {
      counts[row.status as keyof typeof counts] = row.count;
    }
  });
  return counts;
}

// ===== CLAIM QUERIES =====
export async function getClaims(filters?: { status?: string; deviceId?: number }) {
  const db = await getDb();
  if (!db) return [];

  let query: any = db.select().from(claims);

  if (filters?.status) {
    query = query.where(eq(claims.status, filters.status as any));
  }
  if (filters?.deviceId) {
    query = query.where(eq(claims.deviceId, filters.deviceId));
  }

  return await query.orderBy(desc(claims.createdAt));
}

export async function getClaimById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(claims).where(eq(claims.id, id)).limit(1);
  return result[0] || null;
}

export async function createClaim(data: InsertClaim) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(claims).values(data);
  return getClaimById(result[0].insertId);
}

export async function updateClaimStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) return null;
  await db.update(claims).set({ status: status as any }).where(eq(claims.id, id));
  return getClaimById(id);
}

export async function getClaimsForDevice(deviceId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(claims).where(eq(claims.deviceId, deviceId)).orderBy(desc(claims.createdAt));
}

// ===== POLICY QUERIES =====
export async function getPolicies() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(policies).orderBy(policies.policyName);
}

export async function createPolicy(data: InsertPolicy) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(policies).values(data);
  return getPolicies();
}

export async function getPolicyRulesForCategory(category: string) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select({
      rule: policyRules,
      policy: policies,
    })
    .from(policyRules)
    .innerJoin(policies, eq(policyRules.policyId, policies.id))
    .where(
      and(
        eq(policyRules.deviceCategory, category),
        eq(policies.isGloballyActive, 1)
      )
    )
    .orderBy(desc(policyRules.priorityForTieBreak));
}

/**
 * Selects the best matching policy for a given device category.
 * Returns null if no globally-active policy rule covers this category.
 */
export async function selectBestPolicyForCategory(category: string | null) {
  if (!category) return null;
  const matches = await getPolicyRulesForCategory(category);
  return matches.length > 0 ? matches[0] : null;
}

/**
 * Computes the payout for a given device + chosen policy rule.
 * Payout = max(retail_price - deductible, 0).
 */
export function calculatePayout(retailPriceCents: number, deductibleCents: number): number {
  return Math.max(retailPriceCents - deductibleCents, 0);
}

// ===== SYSTEM LOG QUERIES =====
export async function getSystemLogs(filters?: { actor?: string; action?: string; search?: string }) {
  const db = await getDb();
  if (!db) return [];

  let query: any = db.select().from(systemLogs);

  if (filters?.actor) {
    query = query.where(eq(systemLogs.actor, filters.actor));
  }
  if (filters?.action) {
    query = query.where(eq(systemLogs.action, filters.action));
  }
  if (filters?.search) {
    const searchLike = `%${filters.search}%`;
    query = query.where(
      or(
        like(systemLogs.actor, searchLike),
        like(systemLogs.action, searchLike),
        like(systemLogs.details, searchLike)
      )
    );
  }

  return await query.orderBy(desc(systemLogs.timestamp));
}

export async function createSystemLog(actor: string, action: string, details?: any) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(systemLogs).values({
    actor,
    action,
    details: details ? JSON.stringify(details) : null,
  });
}

// ===== DEMO DATA SEEDING =====
export async function seedDemoData() {
  const db = await getDb();
  if (!db) return;

  try {
    // Check if demo data already exists
    const existingDevices = await db.select().from(devices).limit(1);
    if (existingDevices.length > 0) return; // Already seeded

    // Seed policies
    const insertedPolicies = await db.insert(policies).values([
      { policyName: "Asurion Home+", policyShortName: "AH", isGloballyActive: 1 } as InsertPolicy,
      { policyName: "Verizon Home Device Protect", policyShortName: "VZ", isGloballyActive: 1 } as InsertPolicy,
      { policyName: "Protection 360", policyShortName: "P360", isGloballyActive: 1 } as InsertPolicy,
    ]);
    const policyIdByShort: Record<string, number> = {};
    // insertedPolicies may be a result object depending on driver; fall back to re-select.
    const allPolicies = await getPolicies();
    allPolicies.forEach((p) => {
      policyIdByShort[p.policyShortName] = p.id;
    });

    // Seed policy rules (one per category that appears in our seed data)
    const ruleRows: InsertPolicyRule[] = [];
    if (policyIdByShort["AH"]) {
      ruleRows.push(
        { policyId: policyIdByShort["AH"], deviceCategory: "Headphones", deductibleAmount: 5000, isAdhCovered: 0, priorityForTieBreak: 1 } as InsertPolicyRule,
        { policyId: policyIdByShort["AH"], deviceCategory: "Tablet", deductibleAmount: 10000, isAdhCovered: 1, priorityForTieBreak: 1 } as InsertPolicyRule,
        { policyId: policyIdByShort["AH"], deviceCategory: "Laptop", deductibleAmount: 15000, isAdhCovered: 1, priorityForTieBreak: 1 } as InsertPolicyRule,
        { policyId: policyIdByShort["AH"], deviceCategory: "Television", deductibleAmount: 20000, isAdhCovered: 0, priorityForTieBreak: 1 } as InsertPolicyRule,
        { policyId: policyIdByShort["AH"], deviceCategory: "Camera", deductibleAmount: 25000, isAdhCovered: 0, priorityForTieBreak: 1 } as InsertPolicyRule,
        { policyId: policyIdByShort["AH"], deviceCategory: "Gaming", deductibleAmount: 7500, isAdhCovered: 0, priorityForTieBreak: 1 } as InsertPolicyRule,
        { policyId: policyIdByShort["AH"], deviceCategory: "Wearable", deductibleAmount: 5000, isAdhCovered: 0, priorityForTieBreak: 1 } as InsertPolicyRule,
      );
    }
    if (policyIdByShort["VZ"]) {
      ruleRows.push(
        { policyId: policyIdByShort["VZ"], deviceCategory: "Headphones", deductibleAmount: 4000, isAdhCovered: 1, priorityForTieBreak: 2 } as InsertPolicyRule,
        { policyId: policyIdByShort["VZ"], deviceCategory: "Tablet", deductibleAmount: 8000, isAdhCovered: 1, priorityForTieBreak: 2 } as InsertPolicyRule,
        { policyId: policyIdByShort["VZ"], deviceCategory: "Wearable", deductibleAmount: 4000, isAdhCovered: 1, priorityForTieBreak: 2 } as InsertPolicyRule,
      );
    }
    if (policyIdByShort["P360"]) {
      ruleRows.push(
        { policyId: policyIdByShort["P360"], deviceCategory: "Television", deductibleAmount: 15000, isAdhCovered: 0, priorityForTieBreak: 3 } as InsertPolicyRule,
        { policyId: policyIdByShort["P360"], deviceCategory: "Gaming", deductibleAmount: 5000, isAdhCovered: 0, priorityForTieBreak: 3 } as InsertPolicyRule,
        { policyId: policyIdByShort["P360"], deviceCategory: "Laptop", deductibleAmount: 12000, isAdhCovered: 1, priorityForTieBreak: 3 } as InsertPolicyRule,
      );
    }
    if (ruleRows.length > 0) {
      await db.insert(policyRules).values(ruleRows);
    }

    // Seed demo devices (retailPriceEstimate stored in cents)
    const deviceData: InsertDevice[] = [
      { brand: "Sony", model: "WH-1000XM5", serialNumber: "SN001", category: "Headphones", retailPriceEstimate: 39900, status: "VALUATED" },
      { brand: "Apple", model: "iPad Pro 12.9", serialNumber: "SN002", category: "Tablet", retailPriceEstimate: 119900, status: "VALUATED" },
      { brand: "Dell", model: "XPS 13", serialNumber: "SN003", category: "Laptop", retailPriceEstimate: 99900, status: "MANUAL_REVIEW", manualReviewReason: "Price lookup failed - rare configuration" },
      { brand: "Samsung", model: "Galaxy Watch 5", serialNumber: "SN004", category: "Wearable", retailPriceEstimate: 27900, status: "INGESTED" },
      { brand: "LG", model: "OLED55C3PUA", serialNumber: "SN005", category: "Television", retailPriceEstimate: 139900, status: "VALUATED" },
      { brand: "Bose", model: "QuietComfort 45", serialNumber: "SN006", category: "Headphones", retailPriceEstimate: 37900, status: "CLAIMED" },
      { brand: "Canon", model: "EOS R6", serialNumber: "SN007", category: "Camera", retailPriceEstimate: 249900, status: "MANUAL_REVIEW", manualReviewReason: "Unusual device model - requires verification" },
      { brand: "Nintendo", model: "Switch OLED", serialNumber: "SN008", category: "Gaming", retailPriceEstimate: 34900, status: "VALUATED" },
    ];

    for (const device of deviceData) {
      await db.insert(devices).values(device);
    }

    // Seed demo claims (payoutEstimate in cents)
    const claimsData: InsertClaim[] = [
      { deviceId: 1, targetPolicyId: policyIdByShort["AH"] ?? 1, status: "PDF_GENERATED", payoutEstimate: 34900, generatedPdfFilename: "claim_SN001.pdf" },
      { deviceId: 2, targetPolicyId: policyIdByShort["VZ"] ?? 2, status: "SUBMITTED", payoutEstimate: 111900, generatedPdfFilename: "claim_SN002.pdf" },
      { deviceId: 5, targetPolicyId: policyIdByShort["P360"] ?? 3, status: "PDF_GENERATED", payoutEstimate: 124900, generatedPdfFilename: "claim_SN005.pdf" },
      { deviceId: 6, targetPolicyId: policyIdByShort["AH"] ?? 1, status: "SUBMITTED", payoutEstimate: 32900, generatedPdfFilename: "claim_SN006.pdf" },
      { deviceId: 8, targetPolicyId: policyIdByShort["VZ"] ?? 2, status: "PDF_GENERATED", payoutEstimate: 30900, generatedPdfFilename: "claim_SN008.pdf" },
    ];

    for (const claim of claimsData) {
      await db.insert(claims).values(claim);
    }

    // Seed demo system logs
    const now = new Date();
    const logsData: InsertSystemLog[] = [
      { actor: "INGEST_BOT", action: "FILE_PROCESSED", details: JSON.stringify({ filename: "inventory.json", new_devices: 8 }), timestamp: new Date(now.getTime() - 3600000) },
      { actor: "VALUATION_BOT", action: "PRICE_FOUND", details: JSON.stringify({ device_id: 1, price: 399 }), timestamp: new Date(now.getTime() - 3000000) },
      { actor: "CLAIM_BOT", action: "PDF_GENERATED", details: JSON.stringify({ filename: "claim_SN001.pdf" }), timestamp: new Date(now.getTime() - 2400000) },
      { actor: "ADMIN_USER", action: "DEVICE_PRICE_UPDATED", details: JSON.stringify({ device_id: 3, old_price: null, new_price: 999 }), timestamp: new Date(now.getTime() - 1800000) },
      { actor: "VALUATION_BOT", action: "MANUAL_REVIEW_FLAGGED", details: JSON.stringify({ device_id: 3, reason: "price_not_found" }), timestamp: new Date(now.getTime() - 1200000) },
      { actor: "CLAIM_BOT", action: "PDF_GENERATED", details: JSON.stringify({ filename: "claim_SN005.pdf" }), timestamp: new Date(now.getTime() - 600000) },
    ];

    for (const log of logsData) {
      await db.insert(systemLogs).values(log);
    }

    console.log("[Demo Data] Seeding completed successfully");
  } catch (error) {
    console.error("[Demo Data] Seeding failed:", error);
  }
}