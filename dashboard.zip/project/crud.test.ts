import { describe, it, expect, beforeAll } from "vitest";
import {
  getDevices,
  getDeviceById,
  updateDevicePrice,
  updateDeviceStatus,
  updateDeviceManualReviewReason,
  getDeviceCountsByStatus,
  getClaims,
  getSystemLogs,
  getClaimsForDevice,
  selectBestPolicyForCategory,
  calculatePayout,
} from "./db";

/**
 * DB helper (CRUD) tests
 * ----------------------
 * Verifies the low-level query helpers used by the tRPC routers.
 * Requires the demo seed to have run (or equivalent data to be present).
 */
describe("Device CRUD Operations", () => {
  let testDeviceId: number;

  beforeAll(async () => {
    const devices = await getDevices();
    if (devices.length > 0) {
      testDeviceId = devices[0].id!;
    }
  });

  it("should retrieve all devices", async () => {
    const devices = await getDevices();
    expect(devices).toBeDefined();
    expect(Array.isArray(devices)).toBe(true);
    expect(devices.length).toBeGreaterThan(0);
  });

  it("should retrieve device by ID", async () => {
    if (!testDeviceId) return;
    const device = await getDeviceById(testDeviceId);
    expect(device).toBeDefined();
    expect(device?.id).toBe(testDeviceId);
  });

  it("should update device price", async () => {
    if (!testDeviceId) return;
    const newPrice = 50000;
    await updateDevicePrice(testDeviceId, newPrice);
    const updated = await getDeviceById(testDeviceId);
    expect(updated?.retailPriceEstimate).toBe(newPrice);
  });

  it("should update device status", async () => {
    if (!testDeviceId) return;
    const newStatus = "CLAIMED";
    await updateDeviceStatus(testDeviceId, newStatus);
    const updated = await getDeviceById(testDeviceId);
    expect(updated?.status).toBe(newStatus);
  });

  it("should set manual-review reason on a device", async () => {
    if (!testDeviceId) return;
    await updateDeviceManualReviewReason(testDeviceId, "Reason set by test");
    const updated = await getDeviceById(testDeviceId);
    expect(updated?.manualReviewReason).toBe("Reason set by test");

    // Cleanup: clear the reason so other tests are not affected
    await updateDeviceManualReviewReason(testDeviceId, null);
    const cleared = await getDeviceById(testDeviceId);
    expect(cleared?.manualReviewReason).toBeNull();
  });

  it("should get device counts by status", async () => {
    const counts = await getDeviceCountsByStatus();
    expect(counts).toBeDefined();
    expect(counts.INGESTED).toBeGreaterThanOrEqual(0);
    expect(counts.VALUATED).toBeGreaterThanOrEqual(0);
    expect(counts.MANUAL_REVIEW).toBeGreaterThanOrEqual(0);
    expect(counts.CLAIMED).toBeGreaterThanOrEqual(0);
  });

  it("should retrieve claims", async () => {
    const claims = await getClaims();
    expect(claims).toBeDefined();
    expect(Array.isArray(claims)).toBe(true);
  });

  it("should retrieve claims for a specific device", async () => {
    const claims = await getClaims();
    if (claims.length > 0) {
      const deviceId = claims[0].deviceId!;
      const deviceClaims = await getClaimsForDevice(deviceId);
      expect(deviceClaims).toBeDefined();
      deviceClaims.forEach((c) => {
        expect(c.deviceId).toBe(deviceId);
      });
    }
  });

  it("should retrieve system logs", async () => {
    const logs = await getSystemLogs();
    expect(logs).toBeDefined();
    expect(Array.isArray(logs)).toBe(true);
    expect(logs.length).toBeGreaterThan(0);
  });

  it("should filter devices by status", async () => {
    const devices = await getDevices({ status: "VALUATED" });
    expect(devices).toBeDefined();
    expect(Array.isArray(devices)).toBe(true);
    devices.forEach((device) => {
      expect(device.status).toBe("VALUATED");
    });
  });

  it("should filter devices by brand", async () => {
    const devices = await getDevices({ brand: "Sony" });
    expect(devices).toBeDefined();
    expect(Array.isArray(devices)).toBe(true);
    devices.forEach((device) => {
      expect(device.brand).toBe("Sony");
    });
  });

  it("should search devices by model", async () => {
    const devices = await getDevices({ search: "iPad" });
    expect(devices).toBeDefined();
    expect(Array.isArray(devices)).toBe(true);
    if (devices.length > 0) {
      const hasMatch = devices.some((d) =>
        d.model.toLowerCase().includes("ipad")
      );
      expect(hasMatch).toBe(true);
    }
  });
});

describe("Policy Selection + Payout Calculation", () => {
  it("should calculate payout correctly (price > deductible)", () => {
    expect(calculatePayout(100000, 10000)).toBe(90000);
  });

  it("should floor payout at zero when deductible exceeds price", () => {
    expect(calculatePayout(5000, 10000)).toBe(0);
  });

  it("should return zero payout when price equals deductible", () => {
    expect(calculatePayout(10000, 10000)).toBe(0);
  });

  it("should return null when no policy rule matches the category", async () => {
    const match = await selectBestPolicyForCategory("nonexistent-category-xyz");
    expect(match).toBeNull();
  });

  it("should return a matching policy rule for a seeded category", async () => {
    const match = await selectBestPolicyForCategory("Headphones");
    // Either a real match or null depending on seed state, but the call must not throw.
    expect(match === null || typeof match === "object").toBe(true);
  });
});