import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, HardDrive, Hourglass, CheckCircle, FileSignature } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useEffect, useMemo } from "react";
import { toast } from "sonner";

export default function Overview() {
  const { data: stats, isLoading: isLoadingStats } = trpc.dashboard.stats.useQuery();
  const { data: devices } = trpc.devices.list.useQuery({});

  const eligibleDevices = useMemo(
    () =>
      devices?.filter(
        (d: any) =>
          (d.status === "VALUATED" || d.status === "CLAIM_READY") && d.retailPriceEstimate
      ) ?? [],
    [devices]
  );
  const eligibleCount = eligibleDevices.length;
  const totalEligibleValue = eligibleDevices.reduce(
    (sum: number, d: any) => sum + (d.retailPriceEstimate ?? 0),
    0
  );

  useEffect(() => {
    if (eligibleCount > 0) {
      toast.info(`${eligibleCount} device(s) ready for claims`, {
        description: "Open the Devices page to generate claims",
        duration: 5000,
      });
    }
  }, [eligibleCount]);

  const pipelineData = [
    { name: 'Ingested', value: stats?.INGESTED ?? 0, fill: 'hsl(var(--chart-4))' },
    { name: 'Valuated', value: stats?.VALUATED ?? 0, fill: 'hsl(var(--chart-1))' },
    { name: 'Manual Review', value: stats?.MANUAL_REVIEW ?? 0, fill: 'hsl(var(--chart-2))' },
    { name: 'Claim Ready', value: stats?.CLAIM_READY ?? 0, fill: 'hsl(var(--chart-3))' },
    { name: 'Claimed', value: stats?.CLAIMED ?? 0, fill: 'hsl(var(--chart-5))' },
  ];

  const formatCurrency = (cents: number) => `$${(cents / 100).toFixed(2)}`;

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Overview</h2>
      </div>

      {eligibleCount > 0 && (
        <Alert className="border-primary/50 bg-primary/5">
          <CheckCircle className="h-4 w-4 text-primary" />
          <AlertTitle>Claims Ready</AlertTitle>
          <AlertDescription>
            {eligibleCount} device(s) eligible · potential payouts totaling {formatCurrency(totalEligibleValue)}.
            Visit the Devices page to generate claims.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ingested Devices</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isLoadingStats ? "..." : stats?.INGESTED ?? 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valuated Devices</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isLoadingStats ? "..." : stats?.VALUATED ?? 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Manual Review</CardTitle>
            <Hourglass className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isLoadingStats ? "..." : stats?.MANUAL_REVIEW ?? 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Claim Ready</CardTitle>
            <FileSignature className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isLoadingStats ? "..." : stats?.CLAIM_READY ?? 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Claimed Devices</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isLoadingStats ? "..." : stats?.CLAIMED ?? 0}</div>
          </CardContent>
        </Card>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Device Pipeline Progress</CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            <ResponsiveContainer width="100%" height={350}>
              <BarChart data={pipelineData}>
                <XAxis
                  dataKey="name"
                  stroke="hsl(var(--foreground))"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="hsl(var(--foreground))"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(value) => `${value}`}
                />
                <CartesianGrid vertical={false} stroke="hsl(var(--muted))" />
                <Tooltip
                  cursor={{ fill: 'hsl(var(--accent))' }}
                  contentStyle={{ backgroundColor: 'hsl(var(--popover))', borderColor: 'hsl(var(--border))', borderRadius: 'var(--radius)' }}
                  labelStyle={{ color: 'hsl(var(--popover-foreground))' }}
                  itemStyle={{ color: 'hsl(var(--popover-foreground))' }}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}