# Gemini Gem Dashboard - User Guide

## Overview

The Gemini Gem Dashboard is a professional internal operations dashboard for managing insurance claim automation. It provides real-time visibility into device ingestion, valuation, manual review, and claim processing workflows.

## Features

### 1. Overview Page
- **KPI Cards**: Display counts of devices in each pipeline stage:
  - **INGESTED**: Devices newly added to the system
  - **VALUATED**: Devices with confirmed retail price estimates
  - **MANUAL_REVIEW**: Devices flagged for manual price verification
  - **CLAIM_READY**: Devices staged for claim generation (reserved for future use)
  - **CLAIMED**: Devices with submitted insurance claims
- **Device Pipeline Progress Chart**: Visual representation of device flow through the system with color-coded stages
- **Claims Ready Alert**: Notification banner with the count of claim-eligible devices and the *total potential payout* across them
- **Toast Notification**: Triggers whenever new claim-eligible devices are detected

### 2. Devices Page
- **Device Table**: Complete list of all devices with details:
  - Brand, model, serial number, category
  - Retail price estimate (inline editable, in dollars)
  - Current status (humanized)
  - Claims eligibility badge (Eligible / Filed / Review / Not Ready)
- **Filtering & Search**:
  - Filter by status (INGESTED, VALUATED, MANUAL_REVIEW, CLAIM_READY, CLAIMED)
  - Filter by brand
  - Filter by category
  - Search by brand / model / serial number
- **Inline Price Editing**: Update device retail price directly from the table; audit log captures old + new price
- **Claims Eligibility**: Visual indicator showing which devices are eligible for claims
- **Generate Claim Button**: One-click claim generation for eligible devices:
  - Picks the highest-priority globally-active policy rule matching the device category
  - Computes payout = `max(retail_price − deductible, 0)`
  - Creates a `claims` row with status `PDF_GENERATED` and a unique PDF filename
  - Transitions the device to `CLAIMED`
  - Writes an audit-log entry (`CLAIM_GENERATED`) with full context

### 3. Claims Page
- **KPI Strip**: total claims, total payout (filtered), count submitted
- **Claims Table**: View all generated claims with:
  - Device ID, target policy, status badge (color-coded)
  - Payout estimate (USD)
  - Generated PDF filename (monospaced)
  - Creation timestamp
- **Submit Action**: For `PDF_GENERATED` claims, transition to `SUBMITTED` and write an audit-log entry

### 4. Manual Review Queue
- **Pending Review List**: Devices flagged for manual price verification
- **Inline Reason Editing**: Edit `manualReviewReason` directly from the queue
- **Inline Price Entry**: Add or update retail price estimates directly (auto-promotes the device to `VALUATED`)
- **Resolve Action**: Mark a device as resolved (move to `VALUATED`) without changing its price
- **Dismiss Action**: Clear the manual-review reason and re-queue the device as `INGESTED`

### 5. Audit Log
- **System Events**: Complete audit trail of all operations:
  - Actor (INGEST_BOT, VALUATION_BOT, CLAIM_BOT, ADMIN_USER, DASHBOARD_USER, etc.)
  - Action (FILE_PROCESSED, PRICE_FOUND, PDF_GENERATED, CLAIM_GENERATED, CLAIM_SUBMITTED, DEVICE_PRICE_UPDATED, DEVICE_STATUS_UPDATED, DEVICE_REVIEW_REASON_SET, …)
  - Details (JSON-formatted operation details, rendered as `key: value` chips)
  - Timestamp (monospaced, locale-formatted)
- **Search & Filter**:
  - Search box (free text over actor / action / details)
  - Filter by actor
  - Filter by action

## Design

The dashboard features a **professional dark tech/ops aesthetic** with:
- Deep navy background (`#0f172a`)
- Cyan accent color (`#06b6d4`) for primary actions and highlights
- Amber accent color (`#f59e0b`) for secondary emphasis
- Responsive sidebar navigation (resizable between 200-480px, collapsible on mobile)
- Clean, modern typography and spacing
- Custom scrollbar styling
- Status badges, KPI strips, and toast notifications

## Demo Data

On first load, the dashboard automatically seeds realistic sample data:
- **8 sample devices** across various categories (headphones, tablets, laptops, wearables, televisions, cameras, gaming)
- **5 sample claims** with different statuses (PDF_GENERATED, SUBMITTED)
- **6 audit log entries** showing typical system operations
- **3 insurance policies** (Asurion Home+, Verizon Home Device Protect, Protection 360)
- **Policy rules** mapping each category to a deductible + tie-break priority

This allows you to immediately explore all dashboard features without manual setup.

## How to Use

### Generating a Claim from the Dashboard

1. Open the **Devices** page.
2. Locate a row with the **Eligible** badge.
3. Click **Generate Claim**.
4. The dashboard will:
   - Pick the best-matching policy for the device's category
   - Compute the payout (price − deductible)
   - Insert the claim and mark the device CLAIMED
   - Toast the result with the claim ID and payout

### Checking Device Eligibility

1. Navigate to the **Overview** page
2. Look for the "Claims Ready" alert showing how many devices are eligible for claims and the potential payout
3. Go to the **Devices** page to see which devices have the eligibility badge
4. Use the **Generate Claim** button on eligible rows to file a claim

### Updating Device Information

1. Go to the **Devices** page
2. Click the retail-price input on any row and edit it
3. Tab/click away — the audit trail automatically captures the change with old + new price

### Reviewing Manual Queue

1. Navigate to the **Manual Review** page
2. Optionally edit the **Reason** field for any device
3. Either:
   - Enter a price in the **Enter Price ($)** box and tab away (auto-promotes to VALUATED), or
   - Click **Resolve** to mark the device VALUATED without setting a price, or
   - Click **Dismiss** to clear the reason and send the device back to INGESTED

### Tracking Claims

1. Go to the **Claims** page
2. View the KPI strip for totals at a glance
3. Filter by status if needed
4. Click **Submit** on any `PDF_GENERATED` claim to mark it `SUBMITTED`
5. Check the generated PDF filename column for reference

### Auditing Operations

1. Navigate to the **Audit Log** page
2. Use the search box or actor / action dropdowns to narrow the view
3. Each row shows the primary `key: value` plus secondary details on a second line
4. Track who made changes and when

## Navigation

Use the **sidebar** on the left to navigate between pages:
- 🏠 **Overview** - Dashboard summary and KPIs
- 💾 **Devices** - Device management, eligibility, claim generation
- 📄 **Claims** - Claims tracking and submission
- ⏳ **Manual Review** - Manual review queue with price entry + reason editing
- 📋 **Audit Log** - System audit trail with rich filtering

Click the menu icon (☰) to collapse/expand the sidebar. Drag the right edge of the sidebar to resize.

## Technical Details

### Database Schema
- **devices** — Core device records with pricing, status, and manual-review reason
- **claims** — Generated insurance claims linked to devices, with payout + PDF filename
- **policies** — Insurance policy definitions
- **policyRules** — Deductibles, ADH coverage, and tie-break priority per category
- **systemLogs** — Complete audit trail of all operations

### API Endpoints
All dashboard data is accessed via tRPC procedures under `/api/trpc`:
- `dashboard.stats` — Get device counts by status (INGESTED / VALUATED / MANUAL_REVIEW / CLAIM_READY / CLAIMED)
- `devices.list` — List and filter devices
- `devices.getById` — Get device details
- `devices.updatePrice` — Update device price (writes audit log)
- `devices.updateStatus` — Update device status with validation (writes audit log)
- `devices.setManualReviewReason` — Edit manual-review reason (writes audit log)
- `claims.list` — List and filter claims
- `claims.getForDevice` — All claims for one device
- `claims.checkEligibility` — Check if a device is eligible + which policies cover it
- `claims.generate` — Generate a claim for one eligible device
- `claims.submit` — Transition a `PDF_GENERATED` claim to `SUBMITTED`
- `logs.list` — Get system audit logs (search / actor / action filters)

### Eligibility Logic

A device is eligible for claim generation when **all** are true:
- Status is `VALUATED` or `CLAIM_READY`
- A non-null `retailPriceEstimate` exists
- No open claim (status `PROCESSING`, `PDF_GENERATED`, or `SUBMITTED`) already exists for the device
- At least one globally-active `policyRules` row matches the device's category

Payout calculation:
```
payout = max(retail_price_cents − deductible_cents, 0)
```

Policy selection: among policy rules whose category matches the device, the one with the highest `priorityForTieBreak` wins (ties broken by lowest deductible).

### Testing
The dashboard includes comprehensive Vitest coverage:
- DB helper tests (CRUD + payout calc + policy selection)
- tRPC procedure tests (dashboard, devices, claims including `generate`/`submit`, logs)

Run tests with: `pnpm test`

## Support & Troubleshooting

### Demo Data Not Showing?
The dashboard automatically seeds demo data on first server startup. If you don't see data:
1. Restart the server: `pnpm dev`
2. Clear your browser cache
3. Refresh the page

### Filters Not Working?
1. Ensure you're using exact values (e.g., `VALUATED` not `valuated`)
2. Try clearing the filter and reapplying
3. Check the browser console for errors

### "No active policy rule covers category X" Error?
This means no `policyRules` row exists for the device's category, or all matching rules are inactive. Add a row to the `policyRules` table or activate the relevant rule.

### Generate Claim Says "Device already has an open claim"
The mutation refuses to create a second claim when one is `PROCESSING` / `PDF_GENERATED` / `SUBMITTED`. Submit or wait for the existing one first.

## Future Enhancements

Planned features for future releases:
- Real PDFOtter integration (currently stubbed; the Python `gem_brain` worker owns the production PDF pipeline)
- Bulk claim generation for the eligible queue
- CSV export for payouts / per-policy performance reports
- Scheduled batch processing controls
- Email notifications for claim readiness

---

**Version**: 1.1
**Last Updated**: June 2026
**Dashboard URL**: `/dashboard`