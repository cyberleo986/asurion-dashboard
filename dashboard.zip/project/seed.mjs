import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { devices, claims, policies, policyRules, systemLogs } from "../drizzle/schema.ts";

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error("DATABASE_URL environment variable is not set");
  process.exit(1);
}

/**
 * Seed script for the Gemini Gem dashboard.
 *
 * NOTE: This file previously referenced a different schema (`name`, `provider`,
 * `maxCoverageAmount`, `maxCoveragePercentage`, etc.) that did not match the
 * active Drizzle schema in `schema.ts`. It has been rewritten to use the actual
 * columns so it can be run against the live database without errors.
 *
 * Schema mapping (seed.mjs → schema.ts):
 *   policies.name              → policies.policyName
 *   policies.provider          → policies.policyShortName
 *   policyRules.coverage       → policyRules.deductibleAmount (cents)
 *   policyRules.maxCoveragePct → policyRules.priorityForTieBreak
 *   systemLog (singular)       → systemLogs (plural, camelCase table)
 *   devices.manualReviewReason → devices.manualReviewReason (now present)
 */
async function seed() {
  const connection = await mysql.createConnection(DATABASE_URL);
  const db = drizzle(connection);

  console.log("🌱 Seeding demo data...");

  // Clear existing data (children first)
  await db.delete(systemLogs);
  await db.delete(claims);
  await db.delete(policyRules);
  await db.delete(policies);
  await db.delete(devices);

  // Seed policies
  await db.insert(policies).values([
    { policyName: "Asurion Home+", policyShortName: "AH", isGloballyActive: 1 },
    { policyName: "Verizon Home Device Protect", policyShortName: "VZ", isGloballyActive: 1 },
    { policyName: "Protection 360", policyShortName: "P360", isGloballyActive: 1 },
  ]);

  // Re-read policies to grab the auto-incremented ids
  const policyRows = await db.select().from(policies);
  const policyIdByShort = Object.fromEntries(
    policyRows.map((p) => [p.policyShortName, p.id])
  );

  // Seed policy rules (deductibles in cents, priority tie-break higher = better)
  await db.insert(policyRules).values([
    // Asurion Home+
    { policyId: policyIdByShort.AH, deviceCategory: "smartphone", deductibleAmount: 10000, isAdhCovered: 1, priorityForTieBreak: 2 },
    { policyId: policyIdByShort.AH, deviceCategory: "laptop",    deductibleAmount: 15000, isAdhCovered: 1, priorityForTieBreak: 2 },
    { policyId: policyIdByShort.AH, deviceCategory: "tablet",    deductibleAmount: 8000,  isAdhCovered: 1, priorityForTieBreak: 2 },
    { policyId: policyIdByShort.AH, deviceCategory: "smartwatch",deductibleAmount: 4000,  isAdhCovered: 1, priorityForTieBreak: 2 },
    // Verizon
    { policyId: policyIdByShort.VZ, deviceCategory: "smartphone", deductibleAmount: 12000, isAdhCovered: 1, priorityForTieBreak: 3 },
    { policyId: policyIdByShort.VZ, deviceCategory: "laptop",     deductibleAmount: 20000, isAdhCovered: 1, priorityForTieBreak: 3 },
    { policyId: policyIdByShort.VZ, deviceCategory: "tablet",     deductibleAmount: 10000, isAdhCovered: 1, priorityForTieBreak: 3 },
    // Protection 360
    { policyId: policyIdByShort.P360, deviceCategory: "smartphone", deductibleAmount: 9000,  isAdhCovered: 1, priorityForTieBreak: 1 },
    { policyId: policyIdByShort.P360, deviceCategory: "tablet",     deductibleAmount: 7000,  isAdhCovered: 1, priorityForTieBreak: 1 },
    { policyId: policyIdByShort.P360, deviceCategory: "smartwatch", deductibleAmount: 5000,  isAdhCovered: 1, priorityForTieBreak: 1 },
  ]);

  // Seed devices (retailPriceEstimate is stored in cents)
  const deviceData = [
    { brand: "Apple", model: "iPhone 15 Pro", serialNumber: "SN001", category: "smartphone", status: "INGESTED",       retailPriceEstimate: 99900, manualReviewReason: null },
    { brand: "Apple", model: "iPhone 14",     serialNumber: "SN002", category: "smartphone", status: "VALUATED",       retailPriceEstimate: 79900, manualReviewReason: null },
    { brand: "Samsung", model: "Galaxy S24",  serialNumber: "SN003", category: "smartphone", status: "VALUATED",       retailPriceEstimate: 89900, manualReviewReason: null },
    { brand: "Apple", model: "MacBook Pro 16",serialNumber: "SN004", category: "laptop",    status: "MANUAL_REVIEW",  retailPriceEstimate: null,  manualReviewReason: "Price lookup failed - rare configuration" },
    { brand: "Dell", model: "XPS 15",         serialNumber: "SN005", category: "laptop",    status: "VALUATED",       retailPriceEstimate: 129900, manualReviewReason: null },
    { brand: "Apple", model: "iPad Air",      serialNumber: "SN006", category: "tablet",    status: "INGESTED",       retailPriceEstimate: null,  manualReviewReason: null },
    { brand: "Samsung", model: "Galaxy Tab S9", serialNumber: "SN007", category: "tablet", status: "VALUATED",       retailPriceEstimate: 69900, manualReviewReason: null },
    { brand: "Apple", model: "Apple Watch Series 9", serialNumber: "SN008", category: "smartwatch", status: "CLAIMED", retailPriceEstimate: 39900, manualReviewReason: null },
    { brand: "Garmin", model: "Fenix 7X",     serialNumber: "SN009", category: "smartwatch", status: "MANUAL_REVIEW",  retailPriceEstimate: null,  manualReviewReason: "Unusual device model - requires verification" },
    { brand: "Sony", model: "WH-1000XM5",     serialNumber: "SN010", category: "headphones",status: "INGESTED",       retailPriceEstimate: null,  manualReviewReason: null },
  ];

  await db.insert(devices).values(deviceData);

  // Seed claims for some devices
  const claimsData = [
    { deviceId: 2, targetPolicyId: policyIdByShort.P360, status: "PDF_GENERATED", payoutEstimate: 70900, generatedPdfFilename: "claim_001.pdf" },
    { deviceId: 3, targetPolicyId: policyIdByShort.AH,    status: "SUBMITTED",     payoutEstimate: 79900, generatedPdfFilename: "claim_002.pdf" },
    { deviceId: 5, targetPolicyId: policyIdByShort.P360, status: "PDF_GENERATED", payoutEstimate: 120900, generatedPdfFilename: "claim_003.pdf" },
    { deviceId: 8, targetPolicyId: policyIdByShort.AH,    status: "SUBMITTED",     payoutEstimate: 35900, generatedPdfFilename: "claim_004.pdf" },
  ];

  await db.insert(claims).values(claimsData);

  // Seed system logs (timestamp is in ms epoch)
  const now = Date.now();
  const logsData = [
    { actor: "system",        action: "device_ingested",              details: JSON.stringify({ deviceId: 1, brand: "Apple",  model: "iPhone 15 Pro" }), timestamp: new Date(now - 300000) },
    { actor: "system",        action: "device_valuated",              details: JSON.stringify({ deviceId: 2, retailPrice: 79900, reason: "Price lookup successful" }), timestamp: new Date(now - 240000) },
    { actor: "system",        action: "device_flagged_manual_review", details: JSON.stringify({ deviceId: 4, reason: "Price lookup failed - rare configuration" }), timestamp: new Date(now - 180000) },
    { actor: "admin",         action: "device_price_updated",         details: JSON.stringify({ deviceId: 4, oldPrice: null, newPrice: 180000 }), timestamp: new Date(now - 120000) },
    { actor: "CLAIM_BOT",     action: "CLAIM_GENERATED",              details: JSON.stringify({ claimId: 1, deviceId: 2, policyId: policyIdByShort.P360, payout_estimate: 70900 }), timestamp: new Date(now - 60000) },
    { actor: "DASHBOARD_USER", action: "CLAIM_SUBMITTED",             details: JSON.stringify({ claimId: 2, status: "SUBMITTED" }), timestamp: new Date(now - 30000) },
  ];

  await db.insert(systemLogs).values(logsData);

  console.log("✅ Demo data seeded successfully!");
  await connection.end();
}

seed().catch((error) => {
  console.error("❌ Seeding failed:", error);
  process.exit(1);
});