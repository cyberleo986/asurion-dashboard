CREATE TABLE `claims` (
	`id` int AUTO_INCREMENT NOT NULL,
	`deviceId` int,
	`targetPolicyId` int,
	`status` enum('PROCESSING','PDF_GENERATED','FAILED','SUBMITTED','DRY_RUN_COMPLETE') NOT NULL,
	`failureDate` timestamp,
	`failureDescription` text,
	`payoutEstimate` int,
	`generatedPdfFilename` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `claims_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `devices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`brand` varchar(255),
	`model` varchar(255),
	`serialNumber` varchar(255),
	`category` varchar(255),
	`scanilyUrl` text,
	`retailPriceEstimate` int,
	`status` enum('INGESTED','VALUATED','MANUAL_REVIEW','CLAIM_READY','CLAIMED') NOT NULL DEFAULT 'INGESTED',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `devices_id` PRIMARY KEY(`id`),
	CONSTRAINT `devices_serialNumber_unique` UNIQUE(`serialNumber`)
);
--> statement-breakpoint
CREATE TABLE `policies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`policyName` text NOT NULL,
	`policyShortName` varchar(32) NOT NULL,
	`isGloballyActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `policies_id` PRIMARY KEY(`id`),
	CONSTRAINT `policies_policyShortName_unique` UNIQUE(`policyShortName`)
);
--> statement-breakpoint
CREATE TABLE `policyRules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`policyId` int,
	`deviceCategory` text NOT NULL,
	`deductibleAmount` int NOT NULL,
	`isAdhCovered` int NOT NULL DEFAULT 0,
	`priorityForTieBreak` int NOT NULL,
	CONSTRAINT `policyRules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `systemLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	`actor` varchar(255) NOT NULL,
	`action` varchar(255) NOT NULL,
	`details` text,
	CONSTRAINT `systemLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `claims` ADD CONSTRAINT `claims_deviceId_devices_id_fk` FOREIGN KEY (`deviceId`) REFERENCES `devices`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `claims` ADD CONSTRAINT `claims_targetPolicyId_policies_id_fk` FOREIGN KEY (`targetPolicyId`) REFERENCES `policies`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `policyRules` ADD CONSTRAINT `policyRules_policyId_policies_id_fk` FOREIGN KEY (`policyId`) REFERENCES `policies`(`id`) ON DELETE no action ON UPDATE no action;