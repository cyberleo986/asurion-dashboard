import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Search, Filter, RefreshCcw, CheckCircle, AlertCircle, FileSignature } from "lucide-react";
import { useDebounce } from "@/hooks/useDebounce";
import { toast } from "sonner";

const TOTAL_COLUMNS = 9;

export default function Devices() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [brandFilter, setBrandFilter] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const debouncedSearch = useDebounce(search, 500);

  const { data: devices, isLoading, refetch } = trpc.devices.list.useQuery({
    search: debouncedSearch,
    status: statusFilter || undefined,
    brand: brandFilter || undefined,
    category: categoryFilter || undefined,
  });

  const updatePriceMutation = trpc.devices.updatePrice.useMutation({
    onSuccess: () => {
      toast.success("Device price updated.");
      refetch();
    },
    onError: (error) => {
      toast.error("Failed to update device price.", { description: error.message });
    },
  });

  const updateStatusMutation = trpc.devices.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Device status updated.");
      refetch();
    },
    onError: (error) => {
      toast.error("Failed to update device status.", { description: error.message });
    },
  });

  const generateClaimMutation = trpc.claims.generate.useMutation({
    onSuccess: (result) => {
      toast.success("Claim generated.", {
        description: `Claim #${result.claim.id} — payout $${(result.claim.payoutEstimate / 100).toFixed(2)}`,
      });
      refetch();
    },
    onError: (error) => {
      toast.error("Failed to generate claim.", { description: error.message });
    },
  });

  const handlePriceUpdate = (id: number, price: string) => {
    const parsedPrice = parseInt(price, 10);
    if (!isNaN(parsedPrice) && parsedPrice > 0) {
      updatePriceMutation.mutate({ id, price: parsedPrice });
    } else {
      toast.error("Invalid price", { description: "Please enter a valid positive number." });
    }
  };

  const handleStatusUpdate = (id: number, status: string) => {
    updateStatusMutation.mutate({ id, status });
  };

  const handleGenerateClaim = (id: number) => {
    generateClaimMutation.mutate({ deviceId: id });
  };

  const uniqueBrands = Array.from(new Set(devices?.map((d: { brand: string }) => d.brand).filter(Boolean) as string[])).sort();
  const uniqueCategories = Array.from(new Set(devices?.map((d: { category: string }) => d.category).filter(Boolean) as string[])).sort();
  const uniqueStatuses = Array.from(new Set(devices?.map((d: { status: string }) => d.status).filter(Boolean) as string[])).sort();

  const isEligible = (status: string, price: number | null) =>
    (status === "VALUATED" || status === "CLAIM_READY") && Boolean(price);

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Devices</h2>
        <Button onClick={() => refetch()} variant="outline">
          <RefreshCcw className="mr-2 h-4 w-4" /> Refresh
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Device List</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-4 flex-wrap">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by brand, model, serial..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Statuses</SelectItem>
                {uniqueStatuses.map((status) => (
                  <SelectItem key={status} value={status}>
                    {status.replace(/_/g, " ")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={brandFilter} onValueChange={setBrandFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="Filter by Brand" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Brands</SelectItem>
                {uniqueBrands.map((brand) => (
                  <SelectItem key={brand} value={brand}>
                    {brand}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="Filter by Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Categories</SelectItem>
                {uniqueCategories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {(statusFilter || brandFilter || categoryFilter || search) && (
              <Button
                variant="ghost"
                onClick={() => {
                  setStatusFilter("");
                  setBrandFilter("");
                  setCategoryFilter("");
                  setSearch("");
                }}
              >
                Reset Filters
              </Button>
            )}
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Brand</TableHead>
                  <TableHead>Model</TableHead>
                  <TableHead>Serial Number</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Retail Price</TableHead>
                  <TableHead>Claim Eligible</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={TOTAL_COLUMNS} className="h-24 text-center">
                      <Loader2 className="h-6 w-6 animate-spin inline-block mr-2" /> Loading devices...
                    </TableCell>
                  </TableRow>
                ) : devices?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={TOTAL_COLUMNS} className="h-24 text-center">
                      No devices found.
                    </TableCell>
                  </TableRow>
                ) : (
                  devices?.map((device: {
                    id: number;
                    brand: string;
                    model: string;
                    serialNumber: string;
                    category: string;
                    status: string;
                    retailPriceEstimate: number | null;
                  }) => {
                    const eligible = isEligible(device.status, device.retailPriceEstimate);
                    return (
                      <TableRow key={device.id}>
                        <TableCell>{device.id}</TableCell>
                        <TableCell>{device.brand}</TableCell>
                        <TableCell>{device.model}</TableCell>
                        <TableCell>{device.serialNumber}</TableCell>
                        <TableCell>{device.category}</TableCell>
                        <TableCell>{device.status.replace(/_/g, " ")}</TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            defaultValue={device.retailPriceEstimate ? device.retailPriceEstimate / 100 : ""}
                            onBlur={(e) => handlePriceUpdate(device.id, e.target.value)}
                            className="w-24"
                          />
                        </TableCell>
                        <TableCell>
                          {eligible ? (
                            <div className="flex items-center gap-2">
                              <CheckCircle className="h-4 w-4 text-primary" />
                              <span className="text-xs text-primary font-medium">Eligible</span>
                            </div>
                          ) : device.status === "CLAIMED" ? (
                            <div className="flex items-center gap-2">
                              <CheckCircle className="h-4 w-4 text-muted-foreground" />
                              <span className="text-xs text-muted-foreground font-medium">Filed</span>
                            </div>
                          ) : device.status === "MANUAL_REVIEW" ? (
                            <div className="flex items-center gap-2">
                              <AlertCircle className="h-4 w-4 text-secondary" />
                              <span className="text-xs text-secondary font-medium">Review</span>
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">Not Ready</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {eligible && (
                              <Button
                                size="sm"
                                variant="default"
                                disabled={generateClaimMutation.isPending}
                                onClick={() => handleGenerateClaim(device.id)}
                              >
                                <FileSignature className="mr-2 h-4 w-4" /> Generate Claim
                              </Button>
                            )}
                            <Select
                              value={device.status}
                              onValueChange={(newStatus) => handleStatusUpdate(device.id, newStatus)}
                            >
                              <SelectTrigger className="w-[140px]">
                                <SelectValue placeholder="Update Status" />
                              </SelectTrigger>
                              <SelectContent>
                                {uniqueStatuses.map((status) => (
                                  <SelectItem key={status} value={status}>
                                    {status.replace(/_/g, " ")}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}