import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Filter, RefreshCcw, Send } from "lucide-react";
import { toast } from "sonner";

export default function Claims() {
  const [statusFilter, setStatusFilter] = useState("");

  const { data: claims, isLoading, refetch } = trpc.claims.list.useQuery({
    status: statusFilter || undefined,
  });

  const submitClaimMutation = trpc.claims.submit.useMutation({
    onSuccess: (claim) => {
      toast.success(`Claim #${claim.id} submitted.`);
      refetch();
    },
    onError: (error) => {
      toast.error("Failed to submit claim.", { description: error.message });
    },
  });

  const uniqueStatuses = Array.from(
    new Set(claims?.map((c: any) => c.status).filter(Boolean) as string[])
  ).sort();

  const totalPayout = claims?.reduce((sum: number, c: any) => sum + (c.payoutEstimate ?? 0), 0) ?? 0;

  const statusBadgeClasses: Record<string, string> = {
    PDF_GENERATED: "bg-secondary/15 text-secondary",
    SUBMITTED: "bg-primary/15 text-primary",
    PROCESSING: "bg-muted text-muted-foreground",
    FAILED: "bg-destructive/15 text-destructive",
    DRY_RUN_COMPLETE: "bg-muted text-muted-foreground",
  };

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Claims</h2>
        <Button onClick={() => refetch()} variant="outline">
          <RefreshCcw className="mr-2 h-4 w-4" /> Refresh
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Claims</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{claims?.length ?? 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Payout (filtered)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${(totalPayout / 100).toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Submitted</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {claims?.filter((c: any) => c.status === "SUBMITTED").length ?? 0}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Claim List</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-4">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[220px]">
                <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Statuses</SelectItem>
                {uniqueStatuses.map((status) => (
                  <SelectItem key={status} value={status}>
                    {status.replace(/_/g, " ")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {statusFilter && (
              <Button variant="ghost" onClick={() => setStatusFilter("")}>
                Reset Filter
              </Button>
            )}
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Device ID</TableHead>
                  <TableHead>Policy ID</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Payout Estimate</TableHead>
                  <TableHead>PDF Filename</TableHead>
                  <TableHead>Created At</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="h-24 text-center">
                      <Loader2 className="h-6 w-6 animate-spin inline-block mr-2" /> Loading claims...
                    </TableCell>
                  </TableRow>
                ) : claims?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="h-24 text-center">
                      No claims found.
                    </TableCell>
                  </TableRow>
                ) : (
                  claims?.map((claim: {
                    id: number;
                    deviceId: number;
                    targetPolicyId: number;
                    status: string;
                    payoutEstimate: number;
                    generatedPdfFilename: string | null;
                    createdAt: number;
                  }) => (
                    <TableRow key={claim.id}>
                      <TableCell>{claim.id}</TableCell>
                      <TableCell>{claim.deviceId}</TableCell>
                      <TableCell>{claim.targetPolicyId}</TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                            statusBadgeClasses[claim.status] ?? "bg-muted text-muted-foreground"
                          }`}
                        >
                          {claim.status.replace(/_/g, " ")}
                        </span>
                      </TableCell>
                      <TableCell>${(claim.payoutEstimate / 100).toFixed(2)}</TableCell>
                      <TableCell className="font-mono text-xs">
                        {claim.generatedPdfFilename ?? "—"}
                      </TableCell>
                      <TableCell>{new Date(claim.createdAt).toLocaleString()}</TableCell>
                      <TableCell>
                        {claim.status === "PDF_GENERATED" && (
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={submitClaimMutation.isPending}
                            onClick={() => submitClaimMutation.mutate({ claimId: claim.id })}
                          >
                            <Send className="mr-2 h-4 w-4" /> Submit
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}